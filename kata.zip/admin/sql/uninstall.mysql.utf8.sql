-- best to drop tables manually in case data is lost
DROP TABLE IF EXISTS `#__anhson1`;
DROP TABLE IF EXISTS `#__anhson2`;
DROP TABLE IF EXISTS `#__anhson3`;
DROP TABLE IF EXISTS `#__anhson4`;
DROP TABLE IF EXISTS `#__anhson5`;
DROP TABLE IF EXISTS `#__anhson6`;
DROP TABLE IF EXISTS `#__anhson7`;
DROP TABLE IF EXISTS `#__anhson8`;
DROP TABLE IF EXISTS `#__anhson9`;
DROP TABLE IF EXISTS `#__anhson10`;
DROP TABLE IF EXISTS `#__chusau`;
DROP TABLE IF EXISTS `#__anhson`;
DROP TABLE IF EXISTS `#__nhanghi_bill`;
DROP TABLE IF EXISTS `#__nhanghi_sp`;

