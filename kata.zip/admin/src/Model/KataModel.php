<?php
namespace Joomla\Component\Kata\Administrator\Model;
defined('_JEXEC') or die;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Factory\MVCFactoryInterface;
use Joomla\CMS\MVC\Model\ListModel;
use Joomla\CMS\Tag\KataServiceInterface;
use Joomla\Database\ParameterType;
class KataModel extends ListModel
{
	
}
